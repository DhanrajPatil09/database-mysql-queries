--  What are Date Functions?

--  Date functions help you:

-- Get current date
-- Extract parts (year, month, day)
-- Add/subtract dates
-- Format dates

-- 1. Current Date Functions
--  CURDATE()

--  Returns today’s date

SELECT CURDATE();

-- -------------------------------------------------
--  NOW()

--  Returns date + time

SELECT NOW();

-- -------------------------------------------------

--  2. Extract Parts of Date
--  YEAR, MONTH, DAY

SELECT 
YEAR(order_date),
MONTH(order_date),
DAY(order_date)
FROM orders;

SELECT 
DAYNAME(order_date),   -- Monday, Tuesday
MONTHNAME(order_date) -- January, February
FROM orders;

show tables;

--  3. Add / Subtract Dates
--  Add days

SELECT DATE_ADD(CURDATE(), INTERVAL 5 DAY);

--  Shortcut
select CURDATE() + INTERVAL 5 DAY;

--  Subtract days

SELECT DATE_SUB(CURDATE(), INTERVAL 7 DAY);

--  Shortcut
select CURDATE() - INTERVAL 7 DAY;

--  4. Date Filtering (Very Important)
--  Last 7 days

SELECT *
FROM orders
WHERE order_date >= CURDATE() - INTERVAL 7 DAY;


--  Specific range

SELECT *
FROM orders
WHERE order_date BETWEEN '2026-04-01' AND '2026-04-30';

--  5. Formatting Dates
--  DATE_FORMAT()

SELECT DATE_FORMAT(order_date, '%Y-%m') 
FROM orders;

--  Common Formats
-- Format	Meaning
-- %Y	Year (2026)
-- %m	Month (04)
-- %d	Day (09)
-- %M	April
-- %W	Monday

--  6. Difference Between Dates
--  DATEDIFF()

SELECT DATEDIFF('2026-04-10', '2026-04-01');

--  7. Important Real Queries
--  Monthly sales

SELECT 
DATE_FORMAT(order_date, '%Y-%m') AS month,
COUNT(*) 
FROM orders
GROUP BY month;

--  Orders today
SELECT *
FROM orders
WHERE order_date = CURDATE();

--  Last 30 days

SELECT *
FROM orders
WHERE order_date >= CURDATE() - INTERVAL 30 DAY
