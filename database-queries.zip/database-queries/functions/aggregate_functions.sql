-- Date 18-03-2026

-- Aggregate Functions:
-- Aggregate functions perform calculations on multiple rows 
-- and written for single values

-- Eg:
-- Total marks ---> SUM()
-- Average marks ---> AVG()
-- Highest marks ---> MAX()
-- Lowest marks ---> MIN()
-- Total students --> COUNT()

-- SELECT AGG_FUNTION(COL_NAME) FROM TABLE_NAME;

use mydb1;

show tables;

-- drop table employee1;
-- drop table employee;

CREATE TABLE employee (
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    department VARCHAR(50),
    salary INT,
    age INT
);

desc employee;

insert into employee values
(1,'Amit','HR',30000,25),
(2,'Neha','IT',50000,30),
(3,'Raj','IT',60000,28),
(4,'Simaran','Finanace',35000,26),
(5,'Karan','HR',35000,26);

select * from employee;

-- COUNT()
-- Counts the number of rows

-- Syntax:
-- select count(column_name) from table_name;

-- total count of employess

select count(*) from employee;
-- OR

select count(*) as emp_count from employee;

-- count employes in IT department

select count(*) 
from employee
Where department = 'IT';

select count(*) as IT_EMP
from employee
Where department = 'IT';

-- count employees with salary > 40000

select count(*) 
from employee
Where salary > 40000;

-- Names
select name
from employee
Where salary > 40000;

-- SUM() Function
-- calculates total sum of numeric column
-- select SUM(Column_name) from table_name;


-- Q total salry of all employee

select SUM(salary) as Total_amount from employee;

-- Total salary of HR department

select SUM(salary)
 as Total_HR_amount
 from employee
 where department = 'HR';
 
 -- Total salary where age is equal to 25 and dept = HR
 
 select SUM(salary)
 as Total_amount
 from employee
 where age >= 25 AND department = 'HR';
 
  select SUM(salary),COUNT(*)
 as Total_Count
 from employee
 where age >= 25 AND department = 'HR';
 
 select * from employee;
 
 -- AVG()
 -- Finds the average value
 
 -- Syntax:
 -- Select AVG(Column_name) from table_name;
 
 -- find avg salkary of all emp
 
 Select AVG(salary) from employee;
 
 -- avg salary of IT employees
 
SELECT 
    AVG(salary)
FROM
    employee
WHERE
    department = 'IT';
    
-- Date - 20-03-2026
-- Lowest marks ---> MIN()
-- Returns the lowest value

use mydb1;

show tables;

select * from employee;

-- Find lowest salary

select MIN(salary) as MIN_SALARY from employee;

-- (use group by)

-- find youngest employee
select MIN(Age) as MIN_AGE from employee;

-- find min salary in HR dept

select MIN(salary) as MIN_AGE 
from employee
where department = 'HR';

-- second lowest

select min(salary) from employee
where salary !=(select min(salary) as MIN_SALARY from employee);

-- Highest marks ---> MAX()

-- Returns highest value
-- syntax :
-- select max(col_name) from table_name;

-- find highest salary

select max(salary) as MAX_SALARY from employee;

-- second highest

select max(salary) from employee
where salary !=(select max(salary) as MAX_SALARY from employee);


SELECT 
    MAX(salary)
FROM
    employee
WHERE
    salary != (SELECT 
            MAX(salary) AS MAX_SALARY
        FROM
            employee);
            
-- Find highest salary in IT department

select MAX(salary) 
from employee
where department = 'IT';

-- GROUP BY CLAUSE:

-- Group by used group rows having the same values 
-- in specifiend column and apply aggregate funstion on them

-- Syntax:

-- select column_name ,
-- aggregate_fumnction(column_name)
-- from Table_name 
-- group by column_name;

-- example:
-- find department wise total salary?

select department,
SUM(salary) as Total_salary
from employee 
group by department;


-- Find avg salary per dept?

select department,
AVG(salary) as Average_salary
from employee 
group by department;

-- find number of employee in each depatment?

select department,
COUNT(*) as NUM_EMP
from employee
group by department;

-- Highest salary in each department?

select department,
MAX(salary) as Highest_SALARY
from employee
group by department;

select department,
sum(salary),count(*),avg(salary),MAX(salary),MIN(salary)
from employee
group by department;

-- HAVING CLAUSE ------------
-- Having is used to filter the group data (after group by)
-- Where ---> filters the rows
-- Having ---> filters groups

-- Syntax:

-- select col_name
-- aggregate_function(column_name)
-- from table_name
-- group by column_name
-- having condition;


select * from employee;

-- Find department with total salary greater than 60000

select department,
sum(salary) as Total_salary
from employee
group by department
having sum(salary)>60000;

-- OR
select department,
sum(salary) as Total_salary
from employee
group by department
having Total_salary>60000;

-- Find high paying departments (Department with avg salary > 40000);

select department,
avg(salary) as Avg_salary
from employee
group by department
having Avg_salary>40000;

-- Team size analysis
-- departments having more than 1 employee?

select department,
COUNT(*) as NUM_EMP
from employee
group by department
having NUM_EMP>1;

-- Find department where total salary is between 50000 to 90000
-- Budget range analysis

select department,
sum(salary) as Total_salary
from employee
group by department
having Total_salary between 50000 And 90000;

-- sales
CREATE TABLE sales (
    sales_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    category VARCHAR(50),
    region VARCHAR(50),
    sales_amount INT,
    quantity INT,
    sales_date DATE
);

desc sales;

insert into sales values 
(1,'Laptop','Electronics','west',70000,2,'2026-01-10'),
(2,'Mobile','Electronics','south',30000,3,'2024-01-12'),
(3,'shoes','Fashion','west',5000,5,'2024-01-15'),
(4,'T-shirt','Fashion','north',2000,4,'2024-01-18'),
(5,'Laptop','Electronics','south',50000,6,'2024-01-21');

select * from sales;


-- Q. Total sales per region

SELECT 
    region, SUM(sales_amount)
FROM
    sales
GROUP BY region;

select * from sales;

-- Q.Find regions where total sales> 1 lack

select region,
sum(sales_amount) as Total_sales
from sales
group by region
having Total_sales>100000; -- No any single zone exist greater than 1 lack

select region,
sum(sales_amount) as Total_sales
from sales
group by region
having Total_sales>=50000;

-- Q. Avg sales per category 

select category,
avg(sales_amount) as Sales_amount
from sales
group by category;

-- Categories with avg sales > 20000

select category,
avg(sales_amount) as AVG_SALES
from sales
group by category
having AVG_SALES > 20000;


select * from sales;

-- Q.Total quantity sold per product
select product_name,
COUNT(*) as Quanity
from sales
group by product_name;

-- Q.Product sold more than 3 units in total

select product_name,
sum(quantity) as TOTAL_UNITS
from sales
group by product_name
having TOTAL_UNITS >3;













 
 