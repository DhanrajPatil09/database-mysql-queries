--  1. AGGREGATE FUNCTIONS (MOST IMPORTANT )

--  Used with GROUP BY

-- COUNT()   -- number of rows
-- SUM()     -- total
-- AVG()     -- average
-- MAX()     -- highest value
-- MIN()     -- lowest value

--  Example
-- SELECT COUNT(*), SUM(salary), AVG(salary)
-- FROM Employee;


--  2. STRING FUNCTIONS

-- UPPER()      -- convert to uppercase
-- LOWER()      -- convert to lowercase
-- LENGTH()     -- string length
-- CONCAT()     -- combine strings
-- LEFT()       -- first n characters
-- RIGHT()      -- last n characters
-- SUBSTRING()  -- extract part of string
-- TRIM()       -- remove spaces

--  Example
-- SELECT CONCAT(UPPER(LEFT(name,1)), LOWER(SUBSTRING(name,2)))
-- FROM Users;


--  3. DATE FUNCTIONS (VERY IMPORTANT )

-- CURDATE()      -- current date
-- NOW()          -- date + time
-- YEAR()         -- extract year
-- MONTH()        -- extract month
-- DAY()          -- extract day
-- DATE_FORMAT()  -- format date
-- DATEDIFF()     -- difference between dates

--  Example
-- WHERE order_date >= CURDATE() - INTERVAL 7 DAY


--  4. JOIN FUNCTIONS (TABLE RELATION)

-- INNER JOIN
-- LEFT JOIN
-- RIGHT JOIN

--  Not functions but must know concept


--  5. GROUPING FUNCTIONS

-- GROUP BY
-- HAVING

--  Example
-- SELECT department, COUNT(*)
-- FROM Employee
-- GROUP BY department
-- HAVING COUNT(*) > 5;


--  6. WINDOW FUNCTIONS (ADVANCED )

-- ROW_NUMBER()
-- RANK()
-- DENSE_RANK()
-- SUM() OVER()
-- AVG() OVER()

--  Example
-- RANK() OVER (ORDER BY salary DESC)


--  7. CONDITIONAL FUNCTIONS

-- CASE WHEN ... THEN ... ELSE ... END

--  Example
-- SELECT 
-- salary,
-- CASE 
-- WHEN salary > 50000 THEN 'High'
-- ELSE 'Low'
-- END
-- FROM Employee;


--  8. NULL HANDLING

-- IS NULL
-- IS NOT NULL
-- COALESCE()
-- IFNULL()

--  Example
-- SELECT COALESCE(salary, 0)
-- FROM Employee;


--  9. MATHEMATICAL FUNCTIONS

-- ROUND()
-- CEIL()
-- FLOOR()


--  10. SUBQUERY (VERY IMPORTANT )

-- SELECT * 
-- FROM Employee
-- WHERE salary > (
--     SELECT AVG(salary) FROM Employee
-- );