-- CRUD OPERATION


-- Windows functions

-- windows functions perform calculation across
-- a set of rows related to the current row
-- without collapsing rows


-- Group by ----> Reduce rows
-- Windows Function ---> keeps rows + add extra calculations 
-- Why we use Window Functions
-- Keep all rows + still do calculations

-- SYNTAX:

-- select column_name
-- function_name() over (Partition by column_name order by column_name) AS alias     ---> agg func
-- From table_name;

-- Types of windows functions:

-- 1.Aggregation functions
-- SUM()
-- COUNT()
-- MIN()
-- MAX()
-- AVG()

-- 2.Ranking Functions
-- ROW_NUMBER()
-- RANK()
-- DENSE_RANK()
-- NTILE()

-- 3.Values Functions
-- LAG()
-- LEAD()
-- First_value()
-- Last_value()
-- NTH_VALUE()

show databases;

use mydb1;
show tables;


-- 1)Aggregation windows function

CREATE TABLE mysales (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(30),
    department VARCHAR(40),
    salary int,
    salary_amount INT,
    sales_date DATE
);
-- drop table mysales;

insert into mysales values
(1,'Amit','Electronics',50000,20000,'2024-01-01'),
(2,'Neha','Electronics',60000,3000,'2024-02-02'),
(3,'Raj','Clothing',40000,1500,'2024-01-01'),
(4,'Simran','Clothing',45000,1800,'2024-01-02'),
(5,'Pooja','Clothing',48000,2000,'2024-01-03'),
(6,'Karan','Electronics',70000,3500,'2024-01-03');

insert into mysales values
(7,'prakash','Electronics',70000,3500,'2024-01-03');

select * from mysales;


-- Find department wise total salary

-- group by

select department,
SUM(Salary) as Total_salary
from mysales
group by department;  -- collapse the rows

-- windows :

-- select column_name
-- function_name() over (Partition by column_name order by column_name) AS alias     ---> agg func
-- From table_name;

select emp_name,department,salary, sum(salary)
over(partition by department) as total_salary
from mysales;

select department, sum(salary)
over(partition by department) as total_salary
from mysales;

-- Running total of salary_amount

-- 1 2 3 4 5 6 
select * from mysales;

select emp_name,sales_date,salary_amount,
sum(salary_amount) over(order by sales_date) as running_total
from mysales;

-- Average salary per department
select * from mysales;
 
select department,salary,
avg(salary) over (partition by department) as avg_salary
from mysales;

-- homework (department wise count,mean,max)
-- count -- mean -- max

-- --->DEPARTMENT WISE COUNT

select department, COUNT(*)
over(partition by department) as Total_count
from mysales;

select distinct department, COUNT(*)
over(partition by department) as Total_count
from mysales;
 
-- --->DEPARTMENT WISE MIN

select department,salary, MIN(salary)
over(partition by department) as min_salary
from mysales;

-- ---> DEPARTMENT WISE MAX
select department,salary, MAX(salary)
over(partition by department) as max_salary
from mysales;


-- 2.Ranking Functions

-- 1.Row Number:

select emp_name,department,salary,
row_number() over (partition by department order by salary desc) as row_numbers
from mysales;

-- 2.Rank(Gaps allowed)

select emp_name,salary,
rank() over(order by salary desc) as rnk
from mysales;

-- DENSE_RANK :

select emp_name,salary,
dense_rank() over(order by salary desc) as dense_rnk
from mysales;

-- NTILE
-- divide into chunks

select emp_name,salary,
NTILE(2) over(order by salary desc) as ntl
from mysales;

select * from mysales;

-- Find highest salary in each department (department wise salary)

select department,salary, MAX(salary)
over(partition by department) as highest_salary
from mysales;



-- select distinct city 
-- from student
-- where lower(city) In('a','e','i','o','u')
-- AND lower(city, LENGTH(city),1) IN ('a','e','i','o','u');


-- second highest salary using dense rank

select emp_name,salary from(
select emp_name,salary,
dense_rank() over(order by salary desc) as dense_rnk
from mysales) t
where dense_rnk = 2;

select * from employee;

-- Find duplicate records

select emp_id,count(*) emp_count
from employee
group by emp_id
having emp_count >1;

-- 3.Values Functions

-- First_value()
-- Last_value()
-- LAG()
-- LEAD()
-- NTH_VALUE()

-- What is value function?
-- These functions return value from a specific row
-- within a window(partition)

-- SYNTAX: 

-- sunction_name(column_name)
-- over(partition by column order by column)


-- ---> a) First_value

select * from employee;

-- get lowest salary in each dept

select name,department,salary, 
first_value(salary)over(partition by department order by salary asc) as lowest_salary
from employee;

-- get highest salary in each dept

select name,department,salary, 
first_value(salary)over(partition by department order by salary desc) as highest_salary
from employee;

select name,department,salary, 
min(salary)over(partition by department order by salary desc) aslowest_salary -- for comparing
from employee;

-- get highest salary in each dept

select name,department,salary,
last_value(salary)over(partition by department order by salary ) as Highest_value
from employee;   

-- By default last_value() does not give last row of partiton
-- so you must use :

-- rows between unbounded preceding and
-- unbounded following

select name,department,salary,
last_value(salary)over(partition by department order by salary rows between unbounded preceding and
unbounded following) as Highest_value
from employee;  

-- LAG()

-- GET VALUE FROM PREVIOUS ROW
-- LEAD()

-- USE IN TIME BASED ANALYSIS

CREATE TABLE SALES2(
ID INT PRIMARY KEY,
MONTH VARCHAR(30),
SALES INT);

INSERT INTO SALES2 VALUES
(1,'JAN',1000),
(2,'FEB',1500),
(3,'MAR',1200),
(4,'APR',1800);

SELECT * FROM SALES2;

-- GET PREVIOUS MONTH SALES

select month,sales,
lag(sales) over(order by id) as prev_month_sales
from sales2;

select month,sales,
lag(sales,1,0) over(order by id) as prev_month_sales
from sales2;

-- LEAD()

-- GET NEXT MONTH SALES

select month,sales,
lead(sales) over(order by id) as next_month_sales
from sales2;

select month,sales,
lead(sales,2) over(order by id) as next_month_sales -- next 2 months
from sales2;

select month,sales,
lead(sales,1,0) over(order by id) as next_month_sales -- by default 0
from sales2;

-- NTH_VALUE()

select name,department,salary,
nth_value(salary,2)over(partition by department order by salary desc rows between unbounded preceding and
unbounded following ) as second_highest
from employee;


-- Find salary difference from lowest?

-- salary - first_value(salary)

select name,salary,
salary - first_value(salary)over(order by salary) as diff
from employee;

SELECT name,
       salary,
       salary - first_salary AS salary_diff
FROM (
    SELECT name,
           salary,
           FIRST_VALUE(salary) OVER (ORDER BY salary) AS first_salary
    FROM employee
) t;

-- percentage of salary

select name, salary,
(salary/first_salary)*100 from
(select name, salary,
first_value(salary)over(order by salary) as first_salary
from employee) t;


SELECT name,
       salary,
       (salary * 100.0 / (SELECT SUM(salary) FROM employee)) AS salary_percentage
FROM employee;


select * from employee;

select name,salary,(first_salary/salary)*100 as avg_salary from(select name,salary,
first_value(salary)over(order by salary) as first_salary
from employee) t;


show procedure status;
