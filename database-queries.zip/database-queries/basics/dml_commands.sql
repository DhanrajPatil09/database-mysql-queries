create database mydb2;

show databases;

use mydb2;

CREATE TABLE Teacher (
    Teacher_name VARCHAR(50),
    Teacher_id INT,
    Subject VARCHAR(70)
);

desc Teacher;

CREATE TABLE Principle (
    Name VARCHAR(100),
    Prin_Id VARCHAR(50),
    Phone VARCHAR(20)
);


#ADD

Alter table Teacher
ADD address varchar(100);

desc Teacher;

#modify--->MODIFY is used  to change datatype,
Alter table Teacher
modify Teacher_id varchar(20);

desc Teacher;

select * from Teacher;

#Drop

Alter table Teacher
Drop Column Subject;

select * from Teacher;

#Rename

Alter table Teacher
Rename Column Teacher_name to Name;

Select * from Teacher;


# Drop as command
Drop Table Teacher;

select * from Teacher;

# Truncate as command

CREATE TABLE Student1 (
    Student_id INT,
    Name VARCHAR(50),
    Age INT,
    Course VARCHAR(50)
);

# multiple columns
INSERT INTO Student1 VALUES
(1, 'Rahul', 20, 'Computer Science'),
(2, 'Anita', 21, 'Information Technology'),
(3, 'Amit', 19, 'Electronics');

select * from Student1;

# Truncate Student;

select * from Student; # outputs the empty structure

 # Rename Table
 
 Rename table Principle to HOD;
 
 desc HOD;
 
 
 # Insert 
 
 # single values columns
INSERT INTO Student1(Student_id, Name, Age, Course) VALUES
(4, 'Rohan', 22, 'Computer Science');

INSERT INTO Student1 VALUES
(5, 'Rehan', 23, 'Computer Science');

# select

# for retriving all values at a time
select * from Student1;

#single
select Student_id from Student1;

select Student_id,Name from Student1;

select Name,Student_id from Student1;

select * from student1;

#condition based
select * from student1 where Age >= 20;

select*from Student1 where Course = 'Electronics';

# only name

select Name from Student1  where Course = 'Electronics';
# name and age
select Name, Age from Student1  where Course = 'Electronics';


SELECT 
    *
FROM
    student1
ORDER BY Age DESC;

#ascending
SELECT 
    *
FROM
    student1
ORDER BY Age ASC;

# Update 
SET SQL_SAFE_UPDATES = 0;
# used to modify existing data in tableUPDATE Student1 
SELECT 
    *
FROM
    student1
ORDER BY Age DESC;
;

    select * from Student1;
    
UPDATE Student1 
SET Age=25
where Course = 'Electronics';

# DELETE

DELETE from student1
where Student_id=3;

select*from Student1;

DELETE from student1
where Age = 20;

DELETE from Student1
where Age=21;

Create table Course(
c_id int,
c_name varchar(30),
fee float,
c_date date
);

desc Course;
select*from Course;

Insert into Course values
(1,'Sql',55000,'2026-03-12'),
(2,'Python',65000,'2026-04-10'),
(3,'Artificial Intellegence',60000,'2026-04-21'),
(4,'Power BI',45000,'2026-05-01'),
(5,'Machine Learning',40000,'2026-05-12'),
(6,'Python',65000,'2026-04-12'),
(7,'Sql',55000,'2026-03-14');

select*from Course;

SELECT *
FROM Course
WHERE c_name = 'Python'
OR c_name = 'Sql';

UPDATE Course
SET c_name = 'Java'
WHERE c_name = 'Sql';

select*from Course;

DELETE FROM Course 
WHERE
    c_name = 'Python';
    
select*from Course;






    

