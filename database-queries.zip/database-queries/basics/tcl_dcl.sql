-- --------------------------------------------------
-- TCL (Trasnasaction Control Language):
-- --------------------------------------------------

-- TCL  commands are used to manage transactions in database.

-- what is transaction?
-- group of sql operations executed as a single unit.

-- For eg:
	-- Bank transfer() Debit+Credit must both succed.
    
-- TCL Comands:
	-- COMMIT
	-- ROLLBACK
	-- SAVE POINT

-- Properties of Transaction(ACID):
	-- Atomacity --> All or nothing
    -- Consistency --> Data remains valid
    -- Isolation ---> Transaction don't interfer to each other
    -- Durability --->  Changes are permenant
    
use mydb1;


show tables;

CREATE TABLE accounts (
    acc_id INT PRIMARY KEY,
    name VARCHAR(40),
    balance INT
);

insert into accounts values 
(1,'Amit',5000),
(2,'Rohit',3000);
    
select * from accounts;

-- Transfer 1000 from Amit ----> Rohit

-- Without TCL

update accounts
set balance = balance-1000
where acc_id=1;

update accounts
set balance = balance+1000
where acc_id=2;

select * from accounts;

-- Money deducted bu not added

-- ---> To solve this problem we use commit

Start Transaction;

update accounts
set balance = balance-500
where acc_id=1;

update accounts
set balance = balance+500
where acc_id=2;

commit;

select * from accounts;


start transaction;

update accounts
set balance = balance+500
where acc_id=2;

rollback; -- ---> previous values are rolled back 

commit;  -- ---> Changes are permenant


-- ----------------------------------------------------------------
-- SAVE POINT
-- ----------------------------------------------------------------

-- all changes are

select * from accounts;

start transaction;
UPDATE accounts set balance = 3000 where acc_id = 1;
savepoint sp2;
UPDATE accounts set balance = 2000 where acc_id = 2;

rollback to sp2;

select * from accounts;


-- only last changes is undone, previous is safe;




-- --------------------------------------------------------------------------------------------------------------------------
-- --------------------------------------- DCL( Data Query Language) ------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------

-- it decides:
	-- it is used to control access/permision in a database
	--  who can access data
	-- what operations they can perform
    
-- DCL Commands:
	-- GRANT ---> Give permissions.
    -- REVOKE ---> REMOVE Permission
    
-- Importance
-- Banking system
-- E-Commerce app
-- Company databases


select * from employee;


-- Create user

Create user 'intern' identified by '123';

-- Grant Access /Pemission
	-- Give only select acess

GRANT SELECT ON employee to 'intern';

select * from employee;

SHOW TABLES;

-- Remove Acess

revoke select on employee from 'intern';


-- Scenario (Assignment)

-- table ---> Account
-- Manger --> Full access
-- Cleark --> view-update
-- Customer --> only view


-- Types of permission 
	-- select --> Read data
    -- INSERT --> Add data
    -- Delete --> Modify data
    -- All    --> Full access
    
-- grant all preveldge on employee from 'manger';


