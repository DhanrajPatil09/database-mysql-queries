create database mydb1;

show databases;

use mydb1;

CREATE TABLE student (
    s_id INT,
    name VARCHAR(100),
    age INT
);

describe student;

desc student;

select * from student;

CREATE TABLE employee (
    emp_id INT,
    emp_name VARCHAR(100),
    salary INT
);

select * from employee;

CREATE TABLE product (
    prod_id INT,
    produvt_name VARCHAR(70),
    price INT
);

# ------Alter Command----------

alter table employee
ADD email varchar(80);

select * from employee;

alter table employee
ADD phone varchar(10);

select * from employee;

desc employee;

# Modify

Alter table employee
modify emp_name varchar(200); # increase len od datatype 

desc employee;

# ---Drop Column---

Alter table employee
Drop column email;

desc employee;

# -- Rename----

alter table employee
rename column e_namel to e_name;

desc employee;

#----Drop Command---

Drop table employee;

select * from employee;

# ----Truncate command----

# Truncate table emp1;

#----Rename---

use mydb1;

Rename table student to student1;

student1