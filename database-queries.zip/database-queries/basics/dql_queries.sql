-- DQL Data query language
-- It is use for to retrive or fetch data from database
-- The main Command used in DQL is 

-- SELECT 

-- for eg - using select we can 
-- view data
-- filter data
-- sort data 
-- analyze data

-- select syntax :

select column_name from table_name; 

use mydb1;

show tables;

CREATE TABLE student (
    id INT,
    name VARCHAR(50),
    course VARCHAR(50),
    city VARCHAR(50),
    fee FLOAT
);

select * from student;

-- Insert sample data

insert into student values
(1,'Rahul','Python','Pune',25000),
(2,'Sneha','Data science','Mumbai',40000),
(3,'Amit','Python','Pune',25000),
(4,'Priya','Java','Dehli',30000),
(5,'Rohit','Data science','Pune',40000);

select * from student;

SET SQL_SAFE_UPDATES = 0;

UPDATE student
SET city = 'Delhi'
WHERE city = 'Dehli';


select * from student;

-- Distinct Keyword
-- it removes duplicate values from tables


-- check entire 
select distinct * from student;

-- Check for particular column
select distinct course from student;
select distinct city from student;
select distinct fee from student;

select distinct course,city,fee from student;

-- how to show duplicate recrods?

-- WHERE  clause --

-- it is use to filter the records(rows) based on conditions
-- SYNTAX :

-- select column_name
-- from table_name
-- where condition

-- Example:

select * from student 
where city = 'Pune';

select * from student 
where course = 'Python';

-- Comparison Operator 

-- = Equal to
-- > greater than 
-- < less than
-- >= greater than equal to
-- <= less than equal to
-- != not equal to

SELECT 
    *
FROM
    student
WHERE
    fee > 30000;
    
    
SELECT 
    *
FROM
    student
WHERE
    fee < 50000;
    
-- logical operators

-- AND
 -- Both conditions must be true

select * from student
where city = 'Pune' AND course = 'Python';

-- OR 
 -- any condition must be true
 
 select * from student 
 where city='Pune' OR city='Mumbai';
 
 -- NOT
  -- Returns opposite result
  
-- student which are not from pune
select * from student
where not city ='Pune';

-- Between 
 -- Used to filter range of values
 -- retrives(fetch) data from particular range
 
 -- Example:
 
SELECT 
    *
FROM
    student
WHERE
    fee BETWEEN 25000 AND 35000;
    
-- IN operatoe
 -- Use to filter multiple values
 
 -- used for single column operation only
 
select * from student
where city in ('Pune','Mumbai');
 
select * from student
where fee in (25000,30000);

-- Like Operator 

-- used for patterns searching 
-- wildcards
-- % ---> multiple characters
-- _ ---> single character

select * from student
where name like '%a'; -- END WITH A

select * from student
where name like 'a%'; -- END WITH B

select * from student
where name like '%a%'; -- IN BETWEEN STRING

-- from starting -- A at secuond place

select * from student
where name like '_a%'; 

-- from ending --  H at forth place from last
select * from student
where name like '%h_';  

select * from student
where name like '%n___';    

-- Constraints: 

-- Rules applied on columns
-- constrauits are rules applied on columns
-- to restrict the type of data that can be inserted.

-- They help maintain data accuracy and integrity 
-- in databasee

-- Constraints :

-- not null
-- unique
-- primary key
-- forein key
-- check
-- default

-- why contraints are importants?
-- Data accuracy
-- Data consistency
-- Prevent invalid data
-- Maintain relationship

-- Not null constraints:
-- Ensures the column cannot contain NUll Values.alter

-- Syntax:

use mydb1;
drop table student;

CREATE TABLE student (
    id INT NOT NULL,
    name VARCHAR(50),
    age INT
);

desc student;

insert into student(id,name,age) values(1,'Rahul',26);
insert into student(id,age) values(1,26);
select * from student;

-- Unique Constraints:
-- Ensures that all values in a column are different 

CREATE TABLE employee (
    emp_id INT,
    email VARCHAR(50) UNIQUE
);

desc employee;

insert into employee values(1,'abc@gmial.com');
insert into employee values(2,'abcd@gmial.com');
insert into employee values(3,'abcd@gmial.com'); -- Duplicate mail not valid
select * from employee;

-- Primary Key
-- Uniquely identifies each record in table

-- Rules:
-- Cannot be null
-- Must be unique 
-- Only one primary key per table 

show tables;

CREATE TABLE std1 (
    student_id INT PRIMARY KEY,
    name VARCHAR(50),
    course VARCHAR(50)
);

desc std1;

insert into std1 values(1,'Amit','SQL');
insert into std1 values(2,'Rahul','Python');

-- keeping null to id forcefully
insert into std1(name,course) values('Rahul','Python');

insert into std1(student_id,name,course) values(3,'Amit','SQL');

select * from std1;

-- Foriegn Key

-- A foreign key connects two tables & maintains relationships

-- Table 1 : Department
-- Table 2 : Employee

CREATE TABLE department (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

CREATE TABLE emp1 (
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    dept_id INT,
    FOREIGN KEY (dept_id)
		REFERENCES department (dept_id) -- MUL
);
 show tables;
 
 desc emp1;
 
 insert into department values(101, 'HR');
 insert into department values(102, 'IT');
 
 select * from department;
 
 
insert into emp1 values(1,'Rohit',103); -- error for foreign key
 
insert into emp1 values(1,'Rohit',101);
insert into emp1 values(2,'Rahul',102);
  
select* from emp1;

-- check 

CREATE TABLE person1 (
    id INT PRIMARY KEY,
    age INT CHECK (age >= 18)
);

desc person1;

insert into person1 values(1,20);
insert into person1 values(2,18);

select * from person1;

-- Default 
-- Assign Default value if no value is provided 

show tables;

CREATE TABLE employee1 (
    emp_id INT PRIMARY KEY,
    city VARCHAR(50) DEFAULT 'Pune' -- bydefault if value not available it set Pune
);

insert into employee1(emp_id,city) values(1,'Mumbai');
insert into employee1(emp_id) values(2); -- inserts Pune 

select * from employee1;



 
 
 
 














