
-- Having ---> filters groups
-- Where ---> filter rows

-- Aggregate Functions
-- SUM,MIN,MAX,COUNT,AVG

-- SQL JOINS

-- What is joins?
-- MERGE --> at least one column have to same in diff table
-- APPEND ---> All columns must be same

-- Joins is used to combine rows from two or more table based on related column

-- Joins data from multiple table to get
-- meaningful information 


--  Types of joins:
-- 1.Inner Join
-- 2.Left join
-- 3.Right join
-- 4.Full join


-- INNER JOIN
--  Returns only matching records from both tables
-- SYNTAX:

-- select column
-- from table1
-- inner join table 2
-- on table1.column=table2.column;

use mydb1;
show tables;

CREATE TABLE emp (
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    dept_id INT
);

CREATE TABLE department1 (
    dept_id INT PRIMARY KEY,
    DeptName VARCHAR(50)
);

insert into emp values
(1,'Amit',101),
(2,'Neha',102),
(3,'Raj',NULL),
(4,'Sneha',104);

select * from emp;

insert into department1 values
(101,'HR'),
(102,'IT'),
(103,'Finanace');

select * from department1;

SELECT 
    e.name, d.DeptName
FROM
    emp AS e
        INNER JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
    -- OR
    
SELECT 
    e.emp_id,e.name, d.DeptName,d.dept_id
FROM
    emp AS e
        INNER JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
SELECT 
    *
FROM
    emp AS e
        INNER JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
-- LEFT JOIN

-- Returns all record from left table + matching records from right table

-- SYNTAX:

-- select column
-- from table1
-- left join table 2
-- on table1.column=table2.column;

SELECT 
    e.name, d.DeptName
FROM
    emp AS e
        LEFT JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
    
-- Retriving all data

SELECT 
    *
FROM
    emp AS e
        LEFT JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
-- RIGHT JOIN

-- Returns all records from right table + matching records from left table

-- SYNTAX:
-- select column
-- from table1
-- right join table 2
-- on table1.column=table2.column;

SELECT 
    *
FROM
    emp AS e
        RIGHT JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    

-- FULL JOIN
-- Returns all records when there is match in either table 

-- SYNTAX:
-- select column
-- from table1
-- full join table 2
-- on table1.column=table2.column;

select * from emp;
select * from department1;

SELECT 
    *
FROM
    emp AS e
        LEFT JOIN
    department1 AS d ON e.dept_id = d.dept_id
    
union

SELECT 
    *
FROM
    emp AS e
        RIGHT JOIN
    department1 AS d ON e.dept_id = d.dept_id;


-- Q1 Write a query to display emp_names along with there dept names

select * from emp;
select * from department1;

SELECT 
    e.name,d.DeptName
FROM
    emp AS e
        INNER JOIN
    department1 AS d ON e.dept_id = d.dept_id;
    
-- Q2 write a query to display all employees aven if they are not assigned to dept

SELECT 
    e.name,d.DeptName
FROM
    emp AS e
        LEFT JOIN
    department1 AS d ON e.dept_id = d.dept_id
    
union

SELECT 
    e.name,d.DeptName
FROM
    emp AS e
        RIGHT JOIN
    department1 AS d ON e.dept_id = d.dept_id;

-- OR
-- use left join

SELECT 
    e.name,d.DeptName
FROM
    emp AS e
        LEFT JOIN
    department1 AS d ON e.dept_id = d.dept_id;


-- Q3. Write a query to display all depatments even if no employee are assigned 

SELECT 
    e.name,d.DeptName
FROM
    emp AS e
        RIGHT JOIN
    department1 AS d ON e.dept_id = d.dept_id;

-- CROSS JOIN

-- Returns all poissible combinations of rows fromfrom both table

select * from emp
cross join department1;


-- SQL ENGINE EXECUTION FLOW
-- FROM --> JOIN --> IN--> WHERE--> GROUP BY --> HAVING-->SELECT-->DISTINCT
-- --> ORDER BY --> LIMIT

select * from employee;

select department, count(*) as total_emp
from employee 
where salary > 10000
group by department
having total_emp >1
order by total_emp desc limit 1;

select * from employee;


use mydb1; 
show tables;
-- Nested Queries:
-- A nested query (Sub Query ) in a query written inside another sql query.

-- Find employes who earn more than the avg salary

-- step1: Find avg slary
-- step2: Compare employee with that values

-- Syntax:
-- select column_name
-- from table_name
-- where column_name operator(
-- select column_name from table_name);

-- Single row sub query
    -- --> it returns only one value
    -- Eg: 
    
select name 
from employee
where salary > (select avg(salary) from employee);


CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50),
    location VARCHAR(30)
);

insert into departments values 
(1,'HR','Pune'),
(2,'IT','Mumbai'),
(3,'Finance','Delhi'),
(4,'IT','Pune'),
(5,'Finance','Pune');

select * from departments;

-- dept_id

alter table employee
add column dept_id int;

select * from employee;


update employee 
set dept_id = 1
where emp_id = 1;

update employee 
set dept_id = 2
where emp_id = 2;

update employee 
set dept_id = 3
where emp_id = 3;

update employee 
set dept_id = 4
where emp_id = 4;

update employee 
set dept_id = 5
where emp_id = 5;

select * from employee;


-- Multiple row sub query

--  --->returns multiple values 
select name, emp_id
from employee
where dept_id in(
select dept_id from departments where location = 'Pune');


-- correlated sub query
-- ---> runs from each row of outer query

select avg(salary)
from employee as e
where e.dept_id=e.dept_id;

select name,salary
from employee e
where salary >(
select avg(salary)
from employee 
where e.dept_id=e.dept_id);


select * from departments;

-- nested subquery(multi-level)

-- ---> 

SELECT 
    name,salary
FROM
    employee
WHERE
    dept_id in (SELECT 
            dept_id
        FROM
            departments
        WHERE
            location = (SELECT 
                    location
                FROM
                    departments
                WHERE
                    dept_name = 'HR'));
                    
-- Find employees in pune location?

select dept_id
from departments
where location = 'Pune';

  
select *
from employee where dept_id 
in(select dept_id
from departments
where location = 'Pune');

-- Find Departments with no employee

select * from employee;
select * from departments;



select dept_id 
from departments
where NOT EXIST (dept_name);

SELECT dept_id
FROM departments
WHERE dept_name IS NULL;

SELECT dept_id
FROM departments d
WHERE NOT EXISTS (
    SELECT name
    FROM employees e 
    WHERE e.dept_id = d.dept_id
);
-- Q Find second highest salary using subquery
-- Q Find employee earning highest salaryin each department
-- Q Find deparetment with highest paid employee



