-- INVENTORY MANAGEMENT SYSTEM

-- CREATE DATABASE inventory;
use inventory;

CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100),
    price DECIMAL(10 , 2 ),
    stock_qty INT,
    supplier_id INT
);
INSERT INTO PRODUCTS VALUES
(1,'Laptop',75000,70,101),
(2,'TV',35000,55,102),
(3,'Mobile',25000,100,103),
(4,'TV',40000,80,104),
(5,'AC',60000,25,105),
(6,'Fan',15000,85,106),
(7,'AC',65000,60,107),
(8,'Laptop',85000,110,108),
(9,'Mobile',35000,90,109),
(10,'Laptop',65000,55,110);

select * from products;

CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    supplier_name VARCHAR(100),
    contact VARCHAR(15)
);

INSERT INTO suppliers  VALUES
(101,'Amit','9876543210'),
(102,'Rahul','9876543211'),
(103,'Sneha','9876543212'),
(104,'Priya','9876543213'),
(105,'Rohit','9876543214'),
(106,'Neha','9876543215'),
(107,'Karan','9876543216'),
(108,'Pooja','9876543217'),
(109,'Vikas','9876543218'),
(110,'Anjali','9876543219');

select * from suppliers;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100),
    email VARCHAR(100)
);

INSERT INTO customers VALUES
(1,'Suresh','suresh@gmail.com'),
(2,'Mahesh','mahesh@gmail.com'),
(3,'Ramesh','ramesh@gmail.com'),
(4,'Deepak','deepak@gmail.com'),
(5,'Nikita','nikita@gmail.com'),
(6,'Swati','swati@gmail.com'),
(7,'Akash','akash@gmail.com'),
(8,'Komal','komal@gmail.com'),
(9,'Tejas','tejas@gmail.com'),
(10,'Meena','meena@gmail.com');

select * from customers;

CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    order_date DATE,
    FOREIGN KEY (customer_id)
        REFERENCES customers (customer_id)
);

INSERT INTO orders VALUES
(1,1,'2026-09-01'),
(2,2,'2026-09-02'),
(3,3,'2026-09-03'),
(4,4,'2026-09-04'),
(5,5,'2026-09-05'),
(6,6,'2026-09-06'),
(7,7,'2026-09-07'),
(8,8,'2026-09-08'),
(9,9,'2026-09-09'),
(10,10,'2026-09-10');

select * from orders;

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY (order_id)
        REFERENCES orders (order_id),
    FOREIGN KEY (product_id)
        REFERENCES products (product_id)
);


INSERT INTO order_items VALUES
(1, 1, 1,100),
(2, 2, 2,10),
(3, 3, 3,78),
(4, 4, 4,55),
(5, 5, 5,75),
(6, 6, 6,60),
(7, 7, 7,30),
(8, 8, 8,25),
(9, 9, 9,50),
(10, 10, 10,110);

select * from order_items;


-- index
create index product_idx
on products(product_name);


-- List all products along with their supplier names. 
-- • Which products have stock less than 5 units? 
-- • What is the total sales amount of all orders? 
-- • Which products are the best-selling products? 
-- • How many orders has each customer placed? 
-- • Show order details with product names and quantities. 
-- • Which orders were placed in the last 7 days?


select * from products;
select * from suppliers;

-- 1. List all products with teir supplier name

select product_name ,supplier_name
from products as p
inner join suppliers as s
on p.supplier_id = s.supplier_id;

-- 2. which products have stock less than 5 units
select * from products;

select product_name
from products
where stock_qty<5;

select * from orders;
select * from products;
select * from customers;
select * from order_items;

-- 3. What is the total sales amount of all orders?

select 
sum(price*quantity) as total_sales_amount
from orders as o
inner join order_items as oi
on o.order_id=oi.order_id
inner join products as p
on oi.product_id=p.product_id;


select * from products;

-- 4• Which products are the best-selling products? 

select 
p.product_name,
sum(oi.quantity) as total_sold
from products as p
inner join order_items as oi
on p.product_id = oi.product_id
group by p.product_name
order by  total_sold desc;

-- or 

select * from products;

select product_name,
sum(stock_qty) as total_sold
from products
group by product_name
order by total_sold desc;

-- 5.How many orders has each customer placed? 
SELECT 
c.customer_name,
COUNT(o.order_id) AS total_orders
FROM customers c
JOIN orders o 
ON c.customer_id = o.customer_id
GROUP BY c.customer_name;

-- or

select customer_name,quantity
from customers as c
inner join orders as o
on c.customer_id=o.customer_id
inner join order_items as oi
on o.order_id = oi.order_id;

-- 6. Show order details with product names and quantities. 

select * from orders;
select * from products;
select * from customers;
select * from order_items;

SELECT 
o.order_id,
p.product_name,
oi.quantity
FROM orders o
JOIN order_items oi 
ON o.order_id = oi.order_id
JOIN products p 
ON oi.product_id = p.product_id;


-- 7.  Which orders were placed in the last 7 days?

SELECT *
FROM orders
WHERE order_date >= CURDATE() - INTERVAL 7 DAY;

-- 8. who are the top 3 customers based  on number of orders?
select * from orders;
select * from products;
select * from customers;
select * from order_items;
select * from suppliers;


SELECT 
c.customer_name,
SUM(oi.quantity) AS total_quantity
FROM customers c
JOIN orders o 
ON c.customer_id = o.customer_id
JOIN order_items oi 
ON o.order_id = oi.order_id
GROUP BY c.customer_name 
order by total_quantity desc limit 3;

-- 9. what is the total revenue generate per product?
select * from orders;
select * from products;
select * from customers;
select * from order_items;
select * from suppliers;

select product_name,
sum(p.price*oi.quantity) as total_revenue
from products as p
join order_items as oi
on p.product_id=oi.product_id
group by product_name;

-- 10. How many products are supplied by each supplier?

select * from orders;
select * from products;
select * from customers;
select * from order_items;
select * from suppliers;


SELECT 
s.supplier_id,
s.supplier_name,
COUNT(p.product_id) AS total_products
FROM suppliers s
LEFT JOIN products p
ON s.supplier_id = p.supplier_id
GROUP BY s.supplier_id, s.supplier_name;


-- 11. which products have never been sold?
select * from orders;
select * from products;
select * from order_items;

select p.product_name,oi.order_id
from products as p
left join order_items as oi
on p.product_id = oi.product_id
where oi.order_id is null ;

-- 12. what is total amount for each order?
select * from orders;
select * from products;
select * from customers;
select * from order_items;
select * from suppliers;

select o.order_id,
sum(p.price*oi.quantity) as total_amount
from orders as o
inner join order_items as oi
on o.order_id = oi.order_id
inner join products as p
on oi.product_id = p.product_id
group by order_id;

select * from orders;
select * from products;
select * from customers;
select * from order_items;
select * from suppliers;
-- 13. What is monthly sales reports?

SELECT month(o.order_date),
SUM(p.price * oi.quantity) AS total_sales
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
GROUP BY month(o.order_date)
order by month(o.order_date);

-- 14. What is average order value?

SELECT 
AVG(order_total) AS avg_order_value
FROM (
    SELECT 
    o.order_id,
    SUM(p.price * oi.quantity) AS order_total
    FROM orders o
    JOIN order_items oi 
    ON o.order_id = oi.order_id
    JOIN products p 
    ON oi.product_id = p.product_id
    GROUP BY o.order_id
) t;

    SELECT
    avg(p.price * oi.quantity) AS order_total
    FROM order_items oi
    JOIN products p 
    ON oi.product_id = p.product_id;
    
-- 15. which is the most expensive product?

select * from products;

select product_name,
price
from products
order by price desc limit 1;

-- 16. Which is the least selling product?
select * from products;

select p.product_name,
sum(p.price*oi.quantity) as total_sold
from products as p
left join order_items as oi
on p.product_id = oi.order_id
group by p.product_name
order by total_sold limit 1 ;

-- 17. which customers have not placed any order

select c.customer_name
from customers as c
left join orders o
on c.customer_id = o.customer_id
where o.order_id is null;

-- 18. What is the total quantity sold by each supplier?

select s.supplier_name,
sum(oi.quantity) as total_sold_quantity
from suppliers as s
inner join products as p
on s.supplier_id=p.supplier_id
inner join order_items as oi
on  p.product_id = oi.product_id
group by s.supplier_name;

-- 19. What is the running total of sales over time?

SELECT 
o.order_date,
SUM(p.price * oi.quantity) OVER (ORDER BY o.order_date) AS running_total
FROM orders o
JOIN order_items oi 
ON o.order_id = oi.order_id
JOIN products p 
ON oi.product_id = p.product_id;

-- 20. How are products ranked based on total sales?

SELECT 
product_name,
total_sales,
rank() OVER (ORDER BY total_sales desc) AS 'rank'
from
(select 
p.product_name,
sum(p.price*oi.quantity) as total_sales
FROM products p
JOIN order_items oi 
ON p.product_id = oi.product_id
group by p.product_name
)t;