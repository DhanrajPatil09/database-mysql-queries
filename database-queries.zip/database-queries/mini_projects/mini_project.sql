-- Create Database
CREATE DATABASE ecommerce;
USE ecommerce;

-- =========================
-- CUSTOMER TABLE
-- =========================
CREATE TABLE customers (
    cust_id INT PRIMARY KEY,
    cust_name VARCHAR(50),
    e_mail VARCHAR(50),
    phone VARCHAR(15),
    city VARCHAR(50),
    cust_date DATE
);

INSERT INTO customers VALUES
(1,'Ram','ram@gmail.com','9876543210','Pune','2026-01-01'),
(2,'Sham','sham@gmail.com','9876543211','Kolhapur','2026-01-07'),
(3,'John','john@gmail.com','9876543212','Satara','2026-01-02'),
(4,'Hari','hari@gmail.com','9876543213','Sangli','2026-01-06'),
(5,'Om','om@gmail.com','9876543214','Mumbai','2026-01-10');

SELECT * FROM customers;

-- =========================
-- PRODUCT TABLE
-- =========================
CREATE TABLE products (
    prod_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    category VARCHAR(50),
    price DECIMAL(10,2),
    stock INT,
    prod_date DATE
);

INSERT INTO products VALUES
(101,'Laptop','Electronics',55000.00,10,'2026-01-01'),
(102,'Mobile','Electronics',20000.00,25,'2026-01-05'),
(103,'Shoes','Fashion',3000.00,50,'2026-01-07'),
(104,'Watch','Accessories',2500.00,30,'2026-01-08'),
(105,'Headphones','Electronics',1500.00,40,'2026-01-09');

SELECT * FROM products;

-- =========================
-- ORDERS TABLE
-- =========================
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    cust_id INT,
    order_date DATE,
    order_status VARCHAR(50),
    FOREIGN KEY (cust_id) REFERENCES customers(cust_id)
);

INSERT INTO orders VALUES
(1001,1,'2026-02-01','Delivered'),
(1002,2,'2026-02-02','Pending'),
(1003,3,'2026-02-03','Shipped'),
(1004,4,'2026-02-04','Cancelled'),
(1005,5,'2026-02-05','Delivered');

SELECT * FROM orders;

-- =========================
-- ORDER ITEMS TABLE
-- =========================
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    prod_id INT,
    quantity INT,
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (prod_id) REFERENCES products(prod_id)
);

INSERT INTO order_items VALUES
(1,1001,101,1,55000.00),
(2,1002,102,2,20000.00),
(3,1003,103,1,3000.00),
(4,1004,104,3,2500.00),
(5,1005,105,2,1500.00);

SELECT * FROM order_items;

-- =========================
-- VIEW DATA
-- =========================
SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

-- Requirements
-- 1. Data Management (CRUD Operations)
-- You must demonstrate the ability to:
-- • Insert new records (e.g., adding new customers or products)
-- • Update existing records (e.g., modifying product prices)
-- • Delete outdated or incorrect records (e.g., removing old orders)
-- • Retrieve specific data based on conditions --

insert into customers values
(6,'Raj','raj@gmial.com','9876543215','Pune','2026-01-01');

INSERT INTO products VALUES
(106,'Laptop','Electronics',75000.00,10,'2026-01-05');


select c.cust_name,c.cust_id,
count(o.order_id) as Total_order
from customers c
inner join orders o
on c.cust_id = o.cust_id
group by cust_name,cust_id;

--  Who are the top customers based on spending?
-- • Which product is sold the most?
-- • Which customers have not placed any orders?
-- • What is the total revenue generated? 

SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

--  Who are the top customers based on spending?

SELECT 
    c.cust_name, SUM(oi.quantity * p.price) AS total_spend
FROM
    customers c
        INNER JOIN
    orders o ON c.cust_id = o.cust_id
        INNER JOIN
    order_items oi ON o.order_id = oi.order_id
        INNER JOIN
    products p ON oi.prod_id = p.prod_id
GROUP BY c.cust_name
ORDER BY total_spend DESC limit 2;


-- • Which product is sold the most?

SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

select product_name,quantity
from products as p
inner join order_items as oi
on p.prod_id = oi.prod_id
group by product_name,quantity
order by quantity desc limit 1;

select p.product_name,
sum(oi.quantity) as total_quantity
from products as p
inner join order_items as oi
on p.prod_id = oi.prod_id
group by p.product_name
order by total_quantity desc;


-- • Which customers have not placed any orders?

SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

select *
from customers as c
left join orders as o
on c.cust_id = o.cust_id
where order_id is null
;

-- • What is the total revenue generated? 

SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;


with abc as (
SELECT 
    c.cust_name, SUM(oi.quantity * p.price) AS total_spend
FROM
    customers c
        INNER JOIN
    orders o ON c.cust_id = o.cust_id
        INNER JOIN
    order_items oi ON o.order_id = oi.order_id
        INNER JOIN
    products p ON oi.prod_id = p.prod_id
GROUP BY c.cust_name
ORDER BY total_spend DESC
)
select sum(total_spend) as total_revenue from abc;

-- find orders more than one product

SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

select order_id,
count(prod_id) as product_count
from order_items 
group by order_id
having product_count > 1;
