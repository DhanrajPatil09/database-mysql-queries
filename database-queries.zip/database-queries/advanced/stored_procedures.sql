-- STORED PROCEDURE:
-- A store Procedure is a pre compiled collection of SQL statements 
-- stored in database that can be executed whenever needed 

-- Why use strore procedure ?

-- Improves Performance
-- Reduce code repetation 
-- Enhance Security
-- Supports modularity
-- Easy to maintain


-- SYNTAX:

-- DELIMETER //
-- create procedure procedure_name(Parameters)
	-- BEGIN 
		-- SQL Statements
	-- END //
-- DELIMETER;

-- CALL procedure_name(parameters);

use mydb1;
show tables;

select * from emp;
drop table emp;

CREATE TABLE emp (
    Empid INT PRIMARY KEY,
    Name VARCHAR(50),
    salary INT,
    department VARCHAR(30)
);

insert into emp values
(1, 'Rohit', 50000, 'HR'),
(2,'Sakshi',60000,'Finance'),
(3, 'Karan',40000,'IT'),
(4,'Amit',80000,'IT'),
(5,'Kajal',75000,'HR');

select * from emp;

-- create a procedure to get all employee details

DELIMITER //

Create procedure GetEmployee()
	BEGIN
		select * from emp;
	END //
DELIMITER ;

CALL GetEmployee();

-- Get employee with id
-- (Parameterised store procedure)

DELIMITER //
Create procedure GetempbyID(IN emp_id int) -- IN ---> input
	BEGIN
		select * from emp where Empid = emp_id;
	END //
DELIMITER ;

CALL GetempbyID(2);


-- ------------- PRACTICE --------------------------------------

DELIMITER //
 create procedure GetempbySalary(IN emp_salary int)
	BEGIN
		SELECT * FROM emp where Salary = emp_salary ;
    END //
DELIMITER ;

CALL GetempbySalary(50000);

-- ------------------------------------------------------

-- MULTIPLE PARAMETERS

-- drop procedure GetEmpDetails;
select * from emp;

DELIMITER //

Create procedure GetEmpDetails(IN emp_id int, IN emp_salary int)
	BEGIN 
		SELECT * 
        FROM emp
        WHERE Empid = emp_id and Salary = emp_salary;
        
	END //
DELIMITER ;

CALL GetEmpDetails(4,50000);


-- ADD New employee 

DELIMITER //

Create procedure Addemployee(IN emp_id int, IN emp_name varchar(50), IN emp_salary int, emp_dept varchar(30))
	BEGIN 
		INSERT INTO EMP VALUES
        (emp_id,emp_name,emp_salary,emp_dept);
        
	END //
DELIMITER ;

CALL Addemployee(7,'Sejal',100000,'IT');

-- Drop procedure Addemployee;

select * from emp;


-- update salary amit = 5000

DELIMITER //
	create procedure Updateemp(IN emp_id int, emp_salary int)
		BEGIN 
			UPDATE emp
            SET SALARY =  emp_salary
            WHERE Empid = emp_id;
        END //
DELIMITER ;

CALL Updateemp(4,50000);

select * from emp;

-- Delete 
-- show procedure status;
-- drop procedure DeleteEmployee:
DELIMITER //
create procedure DeleteEmployeebyID(IN ID int)
	BEGIN
    Delete from emp where Empid = ID;
    END //
DELIMITER ;

call DeleteEmployee(7);

select * from emp;

-- Get total employee (count)

DELIMITER //

CREATE PROCEDURE Getempcount(OUT total int)
	 BEGIN
		SELECT COUNT(*) INTO TOTAL FROM EMP;
     END //
DELIMITER ;

CALL Getempcount(@total);

select @total;

-- salary increment procedure for it department by 10000

drop procedure SalaryIncrement;

SET SQL_SAFE_UPDATES = 0;
DELIMITER //
 
Create procedure SalaryIncrement(IN inc_salary int)
	BEGIN
		UPDATE emp
        SET SALARY = Salary + inc_salary
        WHERE department = 'HR';
    END //

DELIMITER ;

CALL SalaryIncrement(10000);

select * from emp;

-- create procedure to fetch employess by department

DELIMITER //

CREATE PROCEDURE GetEmployeesByDept(IN dept_name VARCHAR(50))
BEGIN
    SELECT *
    FROM emp
    WHERE department = dept_name;
END //

DELIMITER ;

-- Call
CALL GetEmployeesByDept('HR');

-- create a procedure to count employee per department 

DELIMITER //

CREATE PROCEDURE CountEmpByDept(IN dept_name VARCHAR(50))
BEGIN
    SELECT COUNT(*) AS total_employees
    FROM emp
    WHERE department = dept_name;
END //

DELIMITER ;

-- Call
CALL CountEmpByDept('HR');


