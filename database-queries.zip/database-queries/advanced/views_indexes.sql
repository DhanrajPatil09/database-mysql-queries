-- VIEW

-- A view is a virtual table create from one
-- or more table using  a sql query
-- it does not store data physically
-- it fetches data manually


-- Syntax:
-- create view view_name as 
-- select column1,column2
-- from table_name
-- where condition;

-- Why use view?

-- we have  Employee table with salary info

-- HR should see salary
-- Normal employee should not


-- Create view that hide salary column

-- Types of Views :
	-- 1) Simple view 
    -- 2) Complex view
    
-- Operations on view:
	-- 1) view data
    -- 2) update view 
    -- 3) drop view
    
  -- Only Possible when:
  
    -- view based on single table
    -- no group by, aggregate function
    
    use mydb1;
    
    select * from employee;
    
    -- create view without salary?
    
create view t_without_salary as
select emp_id,name,department,age,dept_id
from employee;

select * from t_without_salary;

insert into t_without_salary values
(7,'Sumit','Finance',30,6);

-- Manager should see only IT department employee

create view t_with_id as
select emp_id,name,department,age,dept_id
from employee
where department = 'IT';

select * from t_with_id;

select * from departments;

create view emp_department_view as
select e.name,d.dept_name
from employee e
join departments d
on e.dept_id=d.dept_id;


select * from t_without_salary;

-- Allow inserting only IT employee via view

create view it_view as
select * from employee
where department = 'IT'
WITH CHECK OPTION;

select * from it_view;

insert into it_view values
(4,'Rahul','HR','70000','2'); -- untill dept = id it will not able to insrt

insert into it_view values
(7,'Rahul','HR','70000',25,'2');

select * from it_view;


-- Manager wants department-wise average salary

show tables;

select * from employee;

create view dept_wise_view as
select department,
sum(salary) as Total_salary
from employee
group by department;

select * from  dept_wise_view;

insert into dept_wise_view values  -- Not possible
('IT',70000);


-- -------------------------------------INDEX----------------------------------------

-- An index is database object that improves
-- speed of data retrial from a table

-- Types of Index :
	-- Single column index
    -- Composite index(Multiple column index)
    
select * from employee;

create index idx_name
on employee(department);

select * from idx_name;

show index from employee;


-- drop index from employee;


-- Multi column index

select * from employee;

create index idx_dept_salary
on employee(department,salary);

show index from employee;


-- Flipkart

-- Table oredrs(milions of records)

select * from orders 
where cust_id=101;

-- without index slower
-- with index on cust_id ----> fast

-- When to use:(mostly)
-- columns used in :
	-- Where
    -- Join
    -- Order by
   
-- When not use index:
	-- small table
    -- columns freuently updated
    -- low uniqueness column
    
SELECT * 
FROM employee
WHERE department = 'IT';   

EXPLAIN SELECT * 
FROM employee
WHERE department = 'IT';
    



