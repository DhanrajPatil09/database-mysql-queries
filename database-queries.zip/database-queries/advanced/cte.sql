-- CTE(Common Table Expression)

-- What is common table expression?

-- A CTE is temporary result set that you can refer within a select, insert, update or delete statements
-- It improves :
	-- Redeability
    -- Reusability
    -- Maintainability
    
    
    -- Why CTE?
    
    -- Instead of writting complex nested queries we use CTE
    
use mydb1;
select * from employee;
    
    -- WITHOUT CTE
    -- (subquery/nested query)

SELECT *
FROM (
    SELECT name, salary,
           RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employee
) t
WHERE rnk = 2;

-- SYNTAX:

-- with cte_name as(
-- select col1,col2
-- from table_name
-- where condition)

with ranked_employee as(
select name,salary,
 RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employee
)
select * from ranked_employee;


-- second highest salary

with ranked_employee as(
select name,salary,
 RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employee
)
select * from ranked_employee
where rnk = 2;


-- Create CTE filter high salary>450000 employee 

select * from employee;

with highest_salary as(
select *
from employee 
where salary > 45000
)

select * from highest_salary;


-- MULTIPLE CTE

with dept_avg as(
select department,avg(salary) as avg_salary
from employee
group by department
),

high_paid as (
select * from employee
where salary > 40000)

select name,salary,avg_salary
from high_paid h
join dept_avg d
on h.department=d.department;

-- Find top 3 highest salary employee

select name, salary,drank from (select name,salary,
dense_rank()over(order by salary desc) as drank
from employee) t
where drank <=3;

-- CTE

with ranked as (
select name,salary,
dense_rank()over(order by salary desc) as drank    
from employee)

select * from ranked where drank <=3;


-- CTE VS SUBQUERY

-- Features                              CTE                                       SUBQUERY

-- Readability                           High                                      Low
-- Reusabilty                            Yes                                       No
-- Complexity                            Easy                                      Complex


-- Temporary(Exist only during execution)
-- Cannot create indexes
-- May affect performance if overused

-- Find employees earning more than average salary using CTE?

with avg_salary as(
select 
AVG(salary) as avg_salary
FROM employee
)
select * from employee 
where salary >(select avg_salary from avg_salary);

-- COUNT EMPLOYEE IN EACH DEPARTMENT USING CTE?

with dept_count as(
select department,
count(*) as total_emp
from employee
group by department)

select * from dept_count;

-- Find employee whose salary is above department avg

with dept_avg as (
select department,
avg(salary) as avg_salary
from employee
group by department)

select *
from employee as e
join dept_avg d
on e.department=d.department
where e.salary >avg_salary;

-- 1. Find employees with same salary

SELECT name, salary
FROM employee
WHERE salary IN (
    SELECT salary
    FROM employee
    GROUP BY salary
    HAVING COUNT(*) > 1
);

WITH emp_salary AS (
    SELECT name, salary,
           DENSE_RANK() OVER (ORDER BY salary) AS drank,
           COUNT(*) OVER (PARTITION BY salary) AS cnt
    FROM employee
)

SELECT name, salary, drank
FROM emp_salary
WHERE cnt > 1;

-- 2. Find diplicate records and reserve and remove them 

with dup_record as (select name , salary,
dense_rank() over (order by salary desc) as drnk,
count(*) over(partition by salary) as cnt
from employee)

select name,salary,drnk from dup_record
where cnt > 1;



WITH emp_cte AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY name, salary ORDER BY name) AS rn
    FROM employee
)

SELECT *
FROM emp_cte
WHERE rn = 1;



